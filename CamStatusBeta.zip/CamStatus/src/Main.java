import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileWriter;
public class Main {
    public static void main(String []args) throws FileNotFoundException
    {
        File oldList = new File("C:\\Users\\Chase\\IdeaProjects\\CamStatus\\src\\camsList.txt");
        File newList = new File("C:\\Users\\Chase\\IdeaProjects\\CamStatus\\src\\newCams.txt");
        Scanner list = new Scanner(oldList);
        Scanner newL = new Scanner(newList);
        ArrayList<String> urls = new ArrayList<String>();
        ArrayList<String> newUrls = new ArrayList<String>();
        int i = 0;
        int x = 1;
        while(list.hasNextLine())
        {
            urls.add(i, list.nextLine());
            i++;
        }

        for(int a = 0; a< urls.size(); a++)
        {
            int code = -1;
            HttpURLConnection connection = null;
           try
           {
            URL u = new URL(urls.get(a));
            try {
                connection = (HttpURLConnection) u.openConnection();
                connection.setRequestMethod("HEAD");
                code = connection.getResponseCode();
            }
            catch(Exception e)
               {

               }

            if(code==200)
            {
                newUrls.add(urls.get(a));
                System.out.println(urls.get(a)+ " returned:"+code);
                FileWriter myWriter = new FileWriter("C:\\Users\\Chase\\IdeaProjects\\CamStatus\\src\\newCams.txt", true);
                myWriter.write(urls.get(a) + System.lineSeparator());
                myWriter.close();

            }
            else
            {
                System.out.println(urls.get(a)+ " returned:"+code);
            }
            }
           catch (IOException e)
            {
         e.printStackTrace();
             } finally
           {
               if (connection != null)
                {
                  connection.disconnect();
                }
           }

        }
    }
}
